// Note: This is a page route, not a dynamic route. It is not called with params, but with query.
// src/routes/register/+page.js

export const ssr = false;