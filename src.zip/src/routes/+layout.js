// filepath /src/routes/+layout.js
export const ssr = false;